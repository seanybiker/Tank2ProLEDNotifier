package com.example.tank2proledapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tank2proledapp.ui.AppConfigActivity
import com.example.tank2proledapp.util.PreferencesManager
import kotlinx.coroutines.*

/**
 * Main activity for Tank 2 Pro LED Notification App
 * Provides interface for configuring LED notifications and testing functionality
 */
class MainActivity : AppCompatActivity() {

    private val TAG = "MainActivity"
    
    // LED hardware control paths
    private val ledRedPath = "/sys/bus/platform/drivers/redblue_leddev/red_led_duty"
    private val ledGreenPath = "/sys/bus/platform/drivers/redblue_leddev/green_led_duty"
    private val ledBluePath = "/sys/bus/platform/drivers/redblue_leddev/blue_led_duty"

    private lateinit var prefsManager: PreferencesManager
    private lateinit var ledController: LedController
    
    private lateinit var tvNotificationAccess: TextView
    private lateinit var rvConfiguredApps: RecyclerView
    private lateinit var btnAddApp: Button
    
    private var testFlashingJob: Job? = null
    private val REQUEST_PERMISSIONS = 123

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        // Initialize components
        prefsManager = PreferencesManager(this)
        ledController = LedController()
        
        initViews()
        setupListeners()
        checkPermissions()
        checkNotificationAccess()
        updateConfiguredAppsList()
    }
    
    private fun initViews() {
        tvNotificationAccess = findViewById(R.id.tv_notification_access)
        rvConfiguredApps = findViewById(R.id.rv_configured_apps)
        btnAddApp = findViewById(R.id.btn_add_app)
        
        // Set up RecyclerView
        rvConfiguredApps.layoutManager = LinearLayoutManager(this)
    }
    
    private fun setupListeners() {
        tvNotificationAccess.setOnClickListener {
            openNotificationAccessSettings()
        }
        
        btnAddApp.setOnClickListener {
            startActivity(Intent(this, AppConfigActivity::class.java))
        }
    }

    private fun checkPermissions() {
        val needed = arrayOf(Manifest.permission.READ_SMS, Manifest.permission.READ_PHONE_STATE)
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQUEST_PERMISSIONS)
        }
    }
    
    private fun checkNotificationAccess() {
        val enabled = isNotificationServiceEnabled()
        if (enabled) {
            tvNotificationAccess.text = "✓ Notification access granted"
            tvNotificationAccess.setBackgroundResource(R.drawable.bg_notification_access_granted)
        } else {
            tvNotificationAccess.text = "Notification access required - Tap to grant"
            tvNotificationAccess.setBackgroundResource(R.drawable.bg_notification_access)
        }
    }
    
    private fun isNotificationServiceEnabled(): Boolean {
        val pkgName = packageName
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return flat != null && flat.contains(pkgName)
    }
    
    private fun openNotificationAccessSettings() {
        try {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to open notification settings", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun updateConfiguredAppsList() {
        // TODO: Implement adapter for configured apps
    }
    
    override fun onResume() {
        super.onResume()
        checkNotificationAccess()
        updateConfiguredAppsList()
    }
    
    // Test functions for LED hardware
    
    fun testLed() {
        if (testFlashingJob?.isActive == true) {
            stopLedTest()
            return
        }
        
        // Show dialog with test options
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_test_led, null)
        val btnRed = view.findViewById<Button>(R.id.btn_test_red)
        val btnGreen = view.findViewById<Button>(R.id.btn_test_green)
        val btnBlue = view.findViewById<Button>(R.id.btn_test_blue)
        val btnSequence = view.findViewById<Button>(R.id.btn_test_sequence)
        val btnStop = view.findViewById<Button>(R.id.btn_test_stop)
        
        val dialog = AlertDialog.Builder(this)
            .setTitle("Test LED")
            .setView(view)
            .setNegativeButton("Close", null)
            .create()
        
        btnRed.setOnClickListener {
            testSolidColor(255, 0, 0)
        }
        
        btnGreen.setOnClickListener {
            testSolidColor(0, 255, 0)
        }
        
        btnBlue.setOnClickListener {
            testSolidColor(0, 0, 255)
        }
        
        btnSequence.setOnClickListener {
            testSequence()
        }
        
        btnStop.setOnClickListener {
            stopLedTest()
        }
        
        dialog.setOnDismissListener {
            stopLedTest()
        }
        
        dialog.show()
    }
    
    private fun testSolidColor(red: Int, green: Int, blue: Int) {
        stopLedTest()
        ledController.setLed(red, green, blue)
    }
    
    private fun testSequence() {
        if (testFlashingJob?.isActive == true) return
        
        testFlashingJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                var count = 0
                while (isActive && count < 15) { // Run for ~5 seconds
                    ledController.setLed(255, 0, 0)  // red
                    delay(300)
                    ledController.setLed(0, 255, 0)  // green
                    delay(300)
                    ledController.setLed(0, 0, 255)  // blue
                    delay(300)
                    ledController.setLed(0, 0, 0)    // off
                    delay(300)
                    count++
                }
                // Auto-stop after sequence completes
                ledController.setLed(0, 0, 0)
            } catch (e: Exception) {
                Log.e(TAG, "Error in test sequence", e)
                ledController.setLed(0, 0, 0)
            }
        }
    }
    
    private fun stopLedTest() {
        testFlashingJob?.cancel()
        ledController.setLed(0, 0, 0)
    }
    
    override fun onDestroy() {
        stopLedTest()
        super.onDestroy()
    }
}