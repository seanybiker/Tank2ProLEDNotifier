package com.example.tank2proledapp

import android.app.Notification
import android.content.Intent
import android.os.IBinder
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.example.tank2proledapp.util.PreferencesManager
import kotlinx.coroutines.*

/**
 * Notification listener service that controls LED patterns based on notifications
 * Uses a safety timeout to prevent LED overheating
 */
class NotificationService : NotificationListenerService() {
    
    private val TAG = "NotificationService"
    private lateinit var ledController: LedController
    private lateinit var prefsManager: PreferencesManager
    private var notificationJob: Job? = null
    
    // Auto-timeout after 1 minute to prevent overheating
    private val AUTO_TIMEOUT_MS = 60000L
    
    override fun onCreate() {
        super.onCreate()
        ledController = LedController()
        prefsManager = PreferencesManager(this)
        Log.d(TAG, "Notification service created")
    }
    
    override fun onBind(intent: Intent?): IBinder? {
        Log.d(TAG, "Service bound")
        return super.onBind(intent)
    }
    
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val packageName = sbn.packageName
        Log.d(TAG, "Notification from: $packageName")
        
        // Skip if not an important notification
        if (!isImportantNotification(sbn)) {
            Log.d(TAG, "Skipping unimportant notification")
            return
        }
        
        // Check if app is configured for LED notifications
        if (prefsManager.isAppEnabled(packageName)) {
            // Get pattern and color configuration
            val patternType = prefsManager.getPatternType(packageName)
            val ledColor = prefsManager.getLedColor(packageName)
            
            // Use configuration
            handleConfiguredNotification(packageName, patternType, ledColor)
        } else {
            // Use default handling for common apps
            handleDefaultNotification(packageName)
        }
    }
    
    private fun isImportantNotification(sbn: StatusBarNotification): Boolean {
        // Check notification flags
        val isOngoing = (sbn.notification.flags and Notification.FLAG_ONGOING_EVENT) != 0
        val isLocalOnly = (sbn.notification.flags and Notification.FLAG_LOCAL_ONLY) != 0
        
        // Get notification category
        val category = sbn.notification.category
        
        // Skip ongoing notifications (like music players)
        if (isOngoing) return false
        
        // Skip local-only notifications (usually not important)
        if (isLocalOnly) return false
        
        // Accept call and message notifications
        if (category == Notification.CATEGORY_CALL || 
            category == Notification.CATEGORY_MESSAGE ||
            category == Notification.CATEGORY_ALARM) {
            return true
        }
        
        // Check if it's a high priority notification
        val priority = sbn.notification.priority
        if (priority >= Notification.PRIORITY_HIGH) {
            return true
        }
        
        return false
    }
    
    private fun handleConfiguredNotification(packageName: String, 
                                             patternType: PreferencesManager.PatternType, 
                                             ledColor: PreferencesManager.LedColor) {
        Log.d(TAG, "Handling configured notification for $packageName with pattern $patternType and color $ledColor")
        
        // Stop any previous pattern
        stopLedPattern()
        
        // Get RGB values for the color
        val (r, g, b) = prefsManager.getRgbForColor(ledColor)
        
        // Start new pattern
        notificationJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                var elapsedTime = 0L
                val startTime = System.currentTimeMillis()
                
                while (isActive && elapsedTime < AUTO_TIMEOUT_MS) {
                    when (patternType) {
                        PreferencesManager.PatternType.BLINKING -> {
                            // Simple on/off pattern
                            ledController.setLed(r, g, b)  // On
                            delay(300)
                            ledController.setLed(0, 0, 0)  // Off
                            delay(300)
                        }
                        
                        PreferencesManager.PatternType.PULSING -> {
                            // Fade in/out effect
                            for (i in 0..10) {
                                val intensity = i / 10.0f
                                ledController.setLed(
                                    (r * intensity).toInt(),
                                    (g * intensity).toInt(),
                                    (b * intensity).toInt()
                                )
                                delay(50)
                            }
                            for (i in 10 downTo 0) {
                                val intensity = i / 10.0f
                                ledController.setLed(
                                    (r * intensity).toInt(),
                                    (g * intensity).toInt(),
                                    (b * intensity).toInt()
                                )
                                delay(50)
                            }
                            delay(300)
                        }
                        
                        PreferencesManager.PatternType.SOLID -> {
                            // Constant light with brief off periods
                            ledController.setLed(r, g, b)
                            delay(1500)
                            ledController.setLed(0, 0, 0)
                            delay(100)
                        }
                    }
                    
                    // Update elapsed time
                    elapsedTime = System.currentTimeMillis() - startTime
                }
                
                // Safety check - ensure LED is off after timeout
                ledController.setLed(0, 0, 0)
                
            } catch (e: Exception) {
                Log.e(TAG, "Error in LED pattern", e)
                // Safety - make sure LED is off in case of error
                ledController.setLed(0, 0, 0)
            }
        }
    }
    
    private fun handleDefaultNotification(packageName: String) {
        // Default handling for common apps if not configured by user
        when (packageName) {
            "com.whatsapp" -> {
                // WhatsApp - Green blinking
                Log.d(TAG, "Default handling for WhatsApp")
                startDefaultLedPattern(DefaultPattern.WHATSAPP)
            }
            "com.android.mms", "com.google.android.apps.messaging" -> {
                // SMS - Blue pattern
                Log.d(TAG, "Default handling for SMS")
                startDefaultLedPattern(DefaultPattern.SMS)
            }
            "com.android.phone", "com.android.incallui", "com.google.android.dialer" -> {
                // Call - Red rapid flashing
                Log.d(TAG, "Default handling for phone call")
                startDefaultLedPattern(DefaultPattern.CALL)
            }
        }
    }
    
    private fun startDefaultLedPattern(pattern: DefaultPattern) {
        // Stop any previous pattern
        stopLedPattern()
        
        notificationJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                var elapsedTime = 0L
                val startTime = System.currentTimeMillis()
                
                while (isActive && elapsedTime < AUTO_TIMEOUT_MS) {
                    when (pattern) {
                        DefaultPattern.WHATSAPP -> {
                            // Green flash pattern for WhatsApp
                            ledController.setLed(0, 255, 0)  // Green on
                            delay(300)
                            ledController.setLed(0, 0, 0)    // Off
                            delay(300)
                        }
                        DefaultPattern.SMS -> {
                            // Blue pulse pattern for SMS
                            ledController.setLed(0, 0, 255)  // Blue on
                            delay(200)
                            ledController.setLed(0, 0, 0)    // Off
                            delay(200)
                            ledController.setLed(0, 0, 255)  // Blue on
                            delay(200)
                            ledController.setLed(0, 0, 0)    // Off
                            delay(1000)
                        }
                        DefaultPattern.CALL -> {
                            // Red fast flash for calls
                            ledController.setLed(255, 0, 0)  // Red on
                            delay(200)
                            ledController.setLed(0, 0, 0)    // Off
                            delay(200)
                        }
                    }
                    
                    // Update elapsed time
                    elapsedTime = System.currentTimeMillis() - startTime
                }
                
                // Safety check - ensure LED is off after pattern ends or times out
                ledController.setLed(0, 0, 0)
                
            } catch (e: Exception) {
                Log.e(TAG, "Error in LED pattern", e)
                // Safety - make sure LED is off in case of error
                ledController.setLed(0, 0, 0)
            }
        }
    }
    
    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        // Stop the LED pattern when notification is dismissed
        stopLedPattern()
    }
    
    private fun stopLedPattern() {
        notificationJob?.cancel()
        
        // Make sure LED is turned off
        CoroutineScope(Dispatchers.IO).launch {
            ledController.setLed(0, 0, 0)
        }
    }
    
    override fun onDestroy() {
        stopLedPattern()
        super.onDestroy()
    }
    
    enum class DefaultPattern {
        WHATSAPP, SMS, CALL
    }
}