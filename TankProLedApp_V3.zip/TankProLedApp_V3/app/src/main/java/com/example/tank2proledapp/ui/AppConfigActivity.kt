package com.example.tank2proledapp.ui

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tank2proledapp.R
import java.util.*

/**
 * Activity for selecting which apps will trigger LED notifications
 */
class AppConfigActivity : AppCompatActivity() {
    
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AppAdapter
    private val appList = ArrayList<AppInfo>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_config)
        
        recyclerView = findViewById(R.id.rv_apps)
        recyclerView.layoutManager = LinearLayoutManager(this)
        
        // Load installed apps
        loadInstalledApps()
        
        // Set up adapter
        adapter = AppAdapter(appList) { appInfo ->
            // Open pattern config when an app is selected
            val intent = Intent(this, PatternConfigActivity::class.java)
            intent.putExtra("packageName", appInfo.packageName)
            intent.putExtra("appName", appInfo.name)
            startActivity(intent)
        }
        recyclerView.adapter = adapter
    }
    
    private fun loadInstalledApps() {
        val pm = packageManager
        val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        
        for (appInfo in installedApps) {
            // Skip system apps
            if (pm.getLaunchIntentForPackage(appInfo.packageName) != null) {
                val name = pm.getApplicationLabel(appInfo).toString()
                val icon = pm.getApplicationIcon(appInfo)
                
                appList.add(AppInfo(name, appInfo.packageName, icon))
            }
        }
        
        // Sort by app name
        appList.sortBy { it.name.lowercase(Locale.getDefault()) }
    }
    
    class AppAdapter(
        private val appList: List<AppInfo>,
        private val onItemClick: (AppInfo) -> Unit
    ) : RecyclerView.Adapter<AppAdapter.ViewHolder>() {
        
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_app, parent, false)
            return ViewHolder(view)
        }
        
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val appInfo = appList[position]
            holder.tvAppName.text = appInfo.name
            holder.tvPackageName.text = appInfo.packageName
            holder.ivAppIcon.setImageDrawable(appInfo.icon)
            
            holder.itemView.setOnClickListener {
                onItemClick(appInfo)
            }
        }
        
        override fun getItemCount() = appList.size
        
        class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val tvAppName: TextView = view.findViewById(R.id.tv_app_name)
            val tvPackageName: TextView = view.findViewById(R.id.tv_package_name)
            val ivAppIcon: ImageView = view.findViewById(R.id.iv_app_icon)
        }
    }
    
    data class AppInfo(
        val name: String,
        val packageName: String,
        val icon: android.graphics.drawable.Drawable
    )
}