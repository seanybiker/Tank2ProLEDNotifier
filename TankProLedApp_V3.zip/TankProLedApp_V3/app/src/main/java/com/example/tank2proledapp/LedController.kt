package com.example.tank2proledapp

import android.util.Log
import java.io.DataOutputStream

/**
 * Handles interaction with the LED hardware on the Tank 2 Pro
 * Uses root access to write to system files that control the LEDs
 */
class LedController {
    private val TAG = "LedController"
    
    // System file paths for LED control
    private val ledRedPath = "/sys/bus/platform/drivers/redblue_leddev/red_led_duty"
    private val ledGreenPath = "/sys/bus/platform/drivers/redblue_leddev/green_led_duty"
    private val ledBluePath = "/sys/bus/platform/drivers/redblue_leddev/blue_led_duty"
    
    // Safety mechanism - track if LEDs are currently on
    private var ledsActive = false
    private var lastActiveTime = 0L
    
    // Maximum time LEDs should be on continuously (1 minute)
    private val MAX_ON_TIME_MS = 60000L
    
    /**
     * Sets the RGB values for the LED
     * 
     * @param red Red component (0-255)
     * @param green Green component (0-255)
     * @param blue Blue component (0-255)
     */
    fun setLed(red: Int, green: Int, blue: Int) {
        try {
            // Update LED status tracking
            ledsActive = !(red == 0 && green == 0 && blue == 0)
            if (ledsActive) {
                lastActiveTime = System.currentTimeMillis()
            }
            
            // Execute root command to write to the LED control files
            val process = Runtime.getRuntime().exec("su")
            val os = DataOutputStream(process.outputStream)
            
            os.writeBytes("echo $red > $ledRedPath\n")
            os.writeBytes("echo $green > $ledGreenPath\n")
            os.writeBytes("echo $blue > $ledBluePath\n")
            os.writeBytes("exit\n")
            os.flush()
            
            val exitCode = process.waitFor()
            if (exitCode != 0) {
                Log.e(TAG, "Error setting LED colors, exit code: $exitCode")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set LED colors", e)
            // Try to turn off LEDs in case of error
            try {
                val process = Runtime.getRuntime().exec("su")
                val os = DataOutputStream(process.outputStream)
                os.writeBytes("echo 0 > $ledRedPath\n")
                os.writeBytes("echo 0 > $ledGreenPath\n")
                os.writeBytes("echo 0 > $ledBluePath\n")
                os.writeBytes("exit\n")
                os.flush()
                process.waitFor()
            } catch (e2: Exception) {
                Log.e(TAG, "Critical error: Failed to turn off LEDs after error", e2)
            }
        }
    }
    
    /**
     * Safety check to ensure LEDs aren't left on for too long
     * Should be called periodically from a background service
     */
    fun performSafetyCheck() {
        if (ledsActive) {
            val currentTime = System.currentTimeMillis()
            if (currentTime - lastActiveTime > MAX_ON_TIME_MS) {
                Log.w(TAG, "Safety timeout: LEDs active for too long, turning off")
                setLed(0, 0, 0)
            }
        }
    }
}