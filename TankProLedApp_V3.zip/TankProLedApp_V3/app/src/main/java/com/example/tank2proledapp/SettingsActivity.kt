package com.example.tank2proledapp

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class SettingsActivity : AppCompatActivity() {
    
    private lateinit var languageRadioGroup: RadioGroup
    private lateinit var saveButton: Button
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        
        // Initialize views
        languageRadioGroup = findViewById(R.id.languageRadioGroup)
        saveButton = findViewById(R.id.btnSaveSettings)
        
        // Get current language setting
        val sharedPrefs = getSharedPreferences("app_settings", Context.MODE_PRIVATE)
        val currentLang = sharedPrefs.getString("language", "en") ?: "en"
        
        // Set radio button based on current language
        when (currentLang) {
            "en" -> findViewById<RadioButton>(R.id.radioEnglish).isChecked = true
            "ru" -> findViewById<RadioButton>(R.id.radioRussian).isChecked = true
        }
        
        // Handle save button click
        saveButton.setOnClickListener {
            val selectedLanguage = when (languageRadioGroup.checkedRadioButtonId) {
                R.id.radioEnglish -> "en"
                R.id.radioRussian -> "ru"
                else -> "en" // Default to English
            }
            
            // Save the selection
            with(sharedPrefs.edit()) {
                putString("language", selectedLanguage)
                apply()
            }
            
            // Apply language change
            setLocale(selectedLanguage)
            
            // Show confirmation and restart the main activity
            Toast.makeText(this, "Language changed", Toast.LENGTH_SHORT).show()
            
            // Restart the app to apply changes fully
            val intent = Intent(this, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
        }
    }
    
    private fun setLocale(languageCode: String) {
        val locale = Locale(languageCode)
        Locale.setDefault(locale)
        
        val config = Configuration(resources.configuration)
        config.setLocale(locale)
        
        resources.updateConfiguration(config, resources.displayMetrics)
    }
    
    companion object {
        // Helper function to apply saved language when app starts
        fun applyLanguage(context: Context) {
            val sharedPrefs = context.getSharedPreferences("app_settings", Context.MODE_PRIVATE)
            val language = sharedPrefs.getString("language", "en") ?: "en"
            
            val locale = Locale(language)
            Locale.setDefault(locale)
            
            val config = Configuration(context.resources.configuration)
            config.setLocale(locale)
            
            context.resources.updateConfiguration(config, context.resources.displayMetrics)
        }
    }
}