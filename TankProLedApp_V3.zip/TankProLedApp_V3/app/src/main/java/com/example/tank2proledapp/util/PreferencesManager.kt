package com.example.tank2proledapp.util

import android.content.Context
import android.content.SharedPreferences

/**
 * Helper class to manage user preferences for LED notifications
 */
class PreferencesManager(context: Context) {
    
    private val PREFS_NAME = "led_notification_prefs"
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    
    // LED pattern types
    enum class PatternType {
        BLINKING, PULSING, SOLID
    }
    
    // LED colors
    enum class LedColor {
        RED, GREEN, BLUE, YELLOW, PURPLE, WHITE
    }
    
    // Save app configuration
    fun saveAppConfig(packageName: String, enabled: Boolean, 
                     patternType: PatternType, ledColor: LedColor) {
        prefs.edit()
            .putBoolean("${packageName}_enabled", enabled)
            .putString("${packageName}_pattern", patternType.toString())
            .putString("${packageName}_color", ledColor.toString())
            .apply()
    }
    
    // Check if app is configured for LED notifications
    fun isAppEnabled(packageName: String): Boolean {
        return prefs.getBoolean("${packageName}_enabled", false)
    }
    
    // Get pattern type for app
    fun getPatternType(packageName: String): PatternType {
        val patternStr = prefs.getString("${packageName}_pattern", PatternType.BLINKING.toString())
        return try {
            PatternType.valueOf(patternStr!!)
        } catch (e: Exception) {
            PatternType.BLINKING
        }
    }
    
    // Get LED color for app
    fun getLedColor(packageName: String): LedColor {
        val colorStr = prefs.getString("${packageName}_color", LedColor.RED.toString())
        return try {
            LedColor.valueOf(colorStr!!)
        } catch (e: Exception) {
            LedColor.RED
        }
    }
    
    // Get all configured app packages
    fun getConfiguredApps(): List<String> {
        val configuredApps = mutableListOf<String>()
        val allPrefs = prefs.all
        
        for (key in allPrefs.keys) {
            if (key.endsWith("_enabled") && allPrefs[key] == true) {
                val packageName = key.substringBefore("_enabled")
                configuredApps.add(packageName)
            }
        }
        
        return configuredApps
    }
    
    // Get RGB values for a color
    fun getRgbForColor(color: LedColor): Triple<Int, Int, Int> {
        return when (color) {
            LedColor.RED -> Triple(255, 0, 0)
            LedColor.GREEN -> Triple(0, 255, 0)
            LedColor.BLUE -> Triple(0, 0, 255)
            LedColor.YELLOW -> Triple(255, 255, 0)
            LedColor.PURPLE -> Triple(255, 0, 255)
            LedColor.WHITE -> Triple(255, 255, 255)
        }
    }
    
    // Clear all preferences
    fun clearAll() {
        prefs.edit().clear().apply()
    }
}