package com.example.tank2proledapp.ui

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.tank2proledapp.LedController
import com.example.tank2proledapp.R
import kotlinx.coroutines.*

/**
 * Activity for configuring LED notification patterns for specific apps
 */
class PatternConfigActivity : AppCompatActivity() {

    private lateinit var tvAppName: TextView
    private lateinit var rgPatterns: RadioGroup
    private lateinit var rbBlinking: RadioButton
    private lateinit var rbPulsing: RadioButton
    private lateinit var rbSolid: RadioButton
    private lateinit var rgColors: RadioGroup
    private lateinit var rbRed: RadioButton
    private lateinit var rbGreen: RadioButton
    private lateinit var rbBlue: RadioButton
    private lateinit var rbYellow: RadioButton
    private lateinit var rbPurple: RadioButton
    private lateinit var btnPreview: Button
    private lateinit var btnSave: Button
    
    private lateinit var packageName: String
    private lateinit var appName: String
    private lateinit var preferences: SharedPreferences
    
    private val ledController = LedController()
    private var previewJob: Job? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pattern_config)
        
        // Get package name from intent
        packageName = intent.getStringExtra("packageName") ?: ""
        appName = intent.getStringExtra("appName") ?: "Unknown App"
        
        if (packageName.isEmpty()) {
            finish()
            return
        }
        
        // Initialize preferences
        preferences = getSharedPreferences("led_patterns", Context.MODE_PRIVATE)
        
        initViews()
        loadSavedSettings()
        setupListeners()
    }
    
    private fun initViews() {
        tvAppName = findViewById(R.id.tv_app_name)
        rgPatterns = findViewById(R.id.rg_patterns)
        rbBlinking = findViewById(R.id.rb_blinking)
        rbPulsing = findViewById(R.id.rb_pulsing)
        rbSolid = findViewById(R.id.rb_solid)
        rgColors = findViewById(R.id.rg_colors)
        rbRed = findViewById(R.id.rb_red)
        rbGreen = findViewById(R.id.rb_green)
        rbBlue = findViewById(R.id.rb_blue)
        rbYellow = findViewById(R.id.rb_yellow)
        rbPurple = findViewById(R.id.rb_purple)
        btnPreview = findViewById(R.id.btn_preview)
        btnSave = findViewById(R.id.btn_save)
        
        tvAppName.text = appName
    }
    
    private fun loadSavedSettings() {
        val pattern = preferences.getString("${packageName}_pattern", "blinking")
        val color = preferences.getString("${packageName}_color", "red")
        
        // Set pattern
        when (pattern) {
            "blinking" -> rbBlinking.isChecked = true
            "pulsing" -> rbPulsing.isChecked = true
            "solid" -> rbSolid.isChecked = true
        }
        
        // Set color
        when (color) {
            "red" -> rbRed.isChecked = true
            "green" -> rbGreen.isChecked = true
            "blue" -> rbBlue.isChecked = true
            "yellow" -> rbYellow.isChecked = true
            "purple" -> rbPurple.isChecked = true
        }
    }
    
    private fun setupListeners() {
        btnPreview.setOnClickListener {
            previewPattern()
        }
        
        btnSave.setOnClickListener {
            saveSettings()
            finish()
        }
    }
    
    private fun getSelectedPattern(): String {
        return when (rgPatterns.checkedRadioButtonId) {
            R.id.rb_blinking -> "blinking"
            R.id.rb_pulsing -> "pulsing"
            R.id.rb_solid -> "solid"
            else -> "blinking" // Default
        }
    }
    
    private fun getSelectedColor(): String {
        return when (rgColors.checkedRadioButtonId) {
            R.id.rb_red -> "red"
            R.id.rb_green -> "green"
            R.id.rb_blue -> "blue"
            R.id.rb_yellow -> "yellow"
            R.id.rb_purple -> "purple"
            else -> "red" // Default
        }
    }
    
    private fun getRgbForColor(color: String): Triple<Int, Int, Int> {
        return when (color) {
            "red" -> Triple(255, 0, 0)
            "green" -> Triple(0, 255, 0)
            "blue" -> Triple(0, 0, 255)
            "yellow" -> Triple(255, 255, 0)
            "purple" -> Triple(255, 0, 255)
            else -> Triple(255, 0, 0) // Default red
        }
    }
    
    private fun previewPattern() {
        // Cancel any existing preview
        previewJob?.cancel()
        
        val pattern = getSelectedPattern()
        val color = getSelectedColor()
        val (r, g, b) = getRgbForColor(color)
        
        previewJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                // Preview for 5 seconds
                val startTime = System.currentTimeMillis()
                
                while (isActive && System.currentTimeMillis() - startTime < 5000) {
                    when (pattern) {
                        "blinking" -> {
                            ledController.setLed(r, g, b)
                            delay(300)
                            ledController.setLed(0, 0, 0)
                            delay(300)
                        }
                        "pulsing" -> {
                            // Fade in
                            for (i in 0..10) {
                                val intensity = i / 10.0f
                                ledController.setLed(
                                    (r * intensity).toInt(),
                                    (g * intensity).toInt(),
                                    (b * intensity).toInt()
                                )
                                delay(50)
                            }
                            // Fade out
                            for (i in 10 downTo 0) {
                                val intensity = i / 10.0f
                                ledController.setLed(
                                    (r * intensity).toInt(),
                                    (g * intensity).toInt(),
                                    (b * intensity).toInt()
                                )
                                delay(50)
                            }
                            delay(300)
                        }
                        "solid" -> {
                            ledController.setLed(r, g, b)
                            delay(1000)
                        }
                    }
                }
                
                // Turn off LED when preview is done
                ledController.setLed(0, 0, 0)
                
            } catch (e: Exception) {
                // Safety - make sure LED is off in case of error
                ledController.setLed(0, 0, 0)
            }
        }
    }
    
    private fun saveSettings() {
        val pattern = getSelectedPattern()
        val color = getSelectedColor()
        
        preferences.edit()
            .putString("${packageName}_pattern", pattern)
            .putString("${packageName}_color", color)
            .apply()
    }
    
    override fun onDestroy() {
        previewJob?.cancel()
        
        // Safety - make sure LED is off when activity is destroyed
        CoroutineScope(Dispatchers.IO).launch {
            ledController.setLed(0, 0, 0)
        }
        
        super.onDestroy()
    }
}