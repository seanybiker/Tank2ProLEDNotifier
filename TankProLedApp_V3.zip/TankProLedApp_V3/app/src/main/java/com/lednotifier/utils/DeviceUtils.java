package com.lednotifier.utils;

import android.os.Build;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * Utility class for device-specific operations and checks.
 */
public class DeviceUtils {

    private static final String TAG = "DeviceUtils";
    
    /**
     * Check if the current device is supported by this app.
     * Currently, only the Unihertz Tank 2 Pro is supported.
     * 
     * @return true if the device is supported, false otherwise
     */
    public static boolean isSupported() {
        String manufacturer = Build.MANUFACTURER.toLowerCase();
        String model = Build.MODEL.toLowerCase();
        
        // Check for Unihertz Tank 2 Pro
        boolean isUnihertz = manufacturer.contains("unihertz");
        boolean isTank2Pro = model.contains("tank 2 pro") || model.contains("tank2pro");
        
        return isUnihertz && isTank2Pro;
    }
    
    /**
     * Check if the device has root access.
     * This would be used as a fallback method if no official API is available.
     * 
     * @return true if the device has root access, false otherwise
     */
    public static boolean hasRootAccess() {
        Process process = null;
        try {
            process = Runtime.getRuntime().exec("su -c id");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line = reader.readLine();
            process.waitFor();
            
            return line != null && line.contains("uid=0");
        } catch (Exception e) {
            return false;
        } finally {
            if (process != null) {
                process.destroy();
            }
        }
    }
    
    /**
     * Get information about the device's LED capabilities.
     * This is a conceptual method that would need to be implemented
     * with real device-specific code.
     * 
     * @return A string describing the LED capabilities
     */
    public static String getLedCapabilities() {
        if (!isSupported()) {
            return "Unsupported device";
        }
        
        // In a real implementation, we would query the device-specific APIs
        // For conceptual purposes, we'll return a placeholder
        
        return "LED Panel: RGB, Position: Rear";
        
        /*
        // Example of how this might be implemented:
        try {
            // Option 1: Using reflection to access hidden system APIs
            Class<?> ledInfoClass = Class.forName("com.unihertz.hardware.LedInfo");
            Object ledInfo = ledInfoClass.getMethod("getInstance").invoke(null);
            boolean hasRgb = (boolean) ledInfoClass.getMethod("supportsRgb").invoke(ledInfo);
            int panelCount = (int) ledInfoClass.getMethod("getPanelCount").invoke(ledInfo);
            
            // Option 2: Using system properties
            String ledType = SystemProperties.get("ro.unihertz.led.type", "unknown");
            
            // Option 3: Using shell commands via root
            if (hasRootAccess()) {
                Process process = Runtime.getRuntime().exec("su -c led_info --capabilities");
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(process.getInputStream()));
                StringBuilder output = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                }
                return output.toString();
            }
            
            return String.format("LED Panels: %d, RGB Support: %b", panelCount, hasRgb);
        } catch (Exception e) {
            Log.e(TAG, "Error getting LED capabilities", e);
            return "Error determining LED capabilities";
        }
        */
    }
    
    /**
     * Check if the device's LED hardware is currently available.
     * Some devices might disable LEDs in certain power modes.
     * 
     * @return true if the LED hardware is available, false otherwise
     */
    public static boolean isLedHardwareAvailable() {
        if (!isSupported()) {
            return false;
        }
        
        // In a real implementation, we would query the device-specific APIs
        // For conceptual purposes, we'll return true for supported devices
        
        return true;
        
        /*
        // Example of how this might be implemented:
        try {
            // Using vendor-specific APIs
            return UnihertzLedApi.isAvailable();
        } catch (Exception e) {
            Log.e(TAG, "Error checking LED hardware availability", e);
            return false;
        }
        */
    }
}
