package com.lednotifier.ui;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.lednotifier.LedController;
import com.lednotifier.R;
import com.lednotifier.models.NotificationPattern;

import org.json.JSONException;

/**
 * Activity for configuring LED notification patterns for a specific app.
 */
public class PatternConfigActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "led_notifier_prefs";
    
    private String packageName;
    private String appName;
    private ApplicationInfo appInfo;
    
    private ImageView ivAppIcon;
    private TextView tvAppName;
    private SeekBar sbDuration;
    private SeekBar sbFlashCount;
    private View colorRed, colorGreen, colorBlue, colorYellow, colorPurple, colorCyan, colorWhite;
    private View selectedColorView;
    private Button btnPreview;
    private Button btnSave;
    private Switch switchEnabled;
    private TextView tvDurationValue;
    private TextView tvFlashCountValue;
    
    private NotificationPattern pattern;
    private LedController ledController;
    private SharedPreferences prefs;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pattern_config);
        
        // Get the package name from the intent
        packageName = getIntent().getStringExtra("package_name");
        if (packageName == null) {
            Toast.makeText(this, "Error: App not specified", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        
        // Get app info
        try {
            PackageManager pm = getPackageManager();
            appInfo = pm.getApplicationInfo(packageName, 0);
            appName = pm.getApplicationLabel(appInfo).toString();
        } catch (PackageManager.NameNotFoundException e) {
            Toast.makeText(this, "Error: App not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        
        // Set up the action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Configure LED Pattern");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        
        // Initialize components
        initViews();
        initPreferences();
        loadPattern();
        updateUI();
        setupListeners();
        
        ledController = new LedController(this);
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (ledController != null) {
            ledController.stopPattern(packageName);
        }
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    private void initViews() {
        ivAppIcon = findViewById(R.id.iv_app_icon);
        tvAppName = findViewById(R.id.tv_app_name);
        sbDuration = findViewById(R.id.sb_duration);
        sbFlashCount = findViewById(R.id.sb_flash_count);
        colorRed = findViewById(R.id.color_red);
        colorGreen = findViewById(R.id.color_green);
        colorBlue = findViewById(R.id.color_blue);
        colorYellow = findViewById(R.id.color_yellow);
        colorPurple = findViewById(R.id.color_purple);
        colorCyan = findViewById(R.id.color_cyan);
        colorWhite = findViewById(R.id.color_white);
        btnPreview = findViewById(R.id.btn_preview);
        btnSave = findViewById(R.id.btn_save);
        switchEnabled = findViewById(R.id.switch_enabled);
        tvDurationValue = findViewById(R.id.tv_duration_value);
        tvFlashCountValue = findViewById(R.id.tv_flash_count_value);
    }
    
    private void initPreferences() {
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }
    
    private void loadPattern() {
        String patternJson = prefs.getString("pattern_" + packageName, "");
        
        if (patternJson.isEmpty()) {
            // Create a new pattern with default values
            pattern = new NotificationPattern();
            pattern.setPackageName(packageName);
            pattern.setAppName(appName);
        } else {
            // Load existing pattern
            try {
                pattern = NotificationPattern.fromJson(patternJson);
            } catch (JSONException e) {
                // If there's an error, create a new default pattern
                pattern = new NotificationPattern();
                pattern.setPackageName(packageName);
                pattern.setAppName(appName);
            }
        }
    }
    
    private void updateUI() {
        // Set app info
        ivAppIcon.setImageDrawable(appInfo.loadIcon(getPackageManager()));
        tvAppName.setText(appName);
        
        // Set current pattern values
        sbDuration.setProgress((pattern.getDuration() / 1000) - 1); // 1-10 seconds
        sbFlashCount.setProgress(pattern.getFlashCount() - 1); // 1-20 flashes
        switchEnabled.setChecked(pattern.isEnabled());
        
        // Update text values
        tvDurationValue.setText(String.format("%d seconds", pattern.getDuration() / 1000));
        tvFlashCountValue.setText(String.format("%d flashes", pattern.getFlashCount()));
        
        // Select the current color
        selectColorView(getColorViewByHex(pattern.getColor()));
    }
    
    private void setupListeners() {
        // Set up color selection
        View.OnClickListener colorClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectColorView(v);
            }
        };
        
        colorRed.setOnClickListener(colorClickListener);
        colorGreen.setOnClickListener(colorClickListener);
        colorBlue.setOnClickListener(colorClickListener);
        colorYellow.setOnClickListener(colorClickListener);
        colorPurple.setOnClickListener(colorClickListener);
        colorCyan.setOnClickListener(colorClickListener);
        colorWhite.setOnClickListener(colorClickListener);
        
        // Set up duration slider
        sbDuration.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int durationSeconds = progress + 1; // 1-10 seconds
                pattern.setDuration(durationSeconds * 1000);
                tvDurationValue.setText(String.format("%d seconds", durationSeconds));
            }
            
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        
        // Set up flash count slider
        sbFlashCount.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int flashCount = progress + 1; // 1-20 flashes
                pattern.setFlashCount(flashCount);
                tvFlashCountValue.setText(String.format("%d flashes", flashCount));
            }
            
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        
        // Set up enabled switch
        switchEnabled.setOnCheckedChangeListener((buttonView, isChecked) -> {
            pattern.setEnabled(isChecked);
        });
        
        // Set up preview button
        btnPreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                previewPattern();
            }
        });
        
        // Set up save button
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                savePattern();
            }
        });
    }
    
    private void selectColorView(View colorView) {
        // Reset all color views
        colorRed.setForeground(null);
        colorGreen.setForeground(null);
        colorBlue.setForeground(null);
        colorYellow.setForeground(null);
        colorPurple.setForeground(null);
        colorCyan.setForeground(null);
        colorWhite.setForeground(null);
        
        // Highlight selected color
        colorView.setForeground(ContextCompat.getDrawable(this, R.drawable.color_selected));
        selectedColorView = colorView;
        
        // Update pattern color
        pattern.setColor(getColorHexFromView(colorView));
    }
    
    private View getColorViewByHex(String hexColor) {
        switch (hexColor.toUpperCase()) {
            case "#FF0000": return colorRed;
            case "#00FF00": return colorGreen;
            case "#0000FF": return colorBlue;
            case "#FFFF00": return colorYellow;
            case "#FF00FF": return colorPurple;
            case "#00FFFF": return colorCyan;
            case "#FFFFFF": return colorWhite;
            default: return colorRed; // Default to red
        }
    }
    
    private String getColorHexFromView(View colorView) {
        int id = colorView.getId();
        
        if (id == R.id.color_red) return "#FF0000";
        if (id == R.id.color_green) return "#00FF00";
        if (id == R.id.color_blue) return "#0000FF";
        if (id == R.id.color_yellow) return "#FFFF00";
        if (id == R.id.color_purple) return "#FF00FF";
        if (id == R.id.color_cyan) return "#00FFFF";
        if (id == R.id.color_white) return "#FFFFFF";
        
        return "#FF0000"; // Default to red
    }
    
    private void previewPattern() {
        ledController.executePattern(pattern);
    }
    
    private void savePattern() {
        try {
            String patternJson = pattern.toJson();
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("pattern_" + packageName, patternJson);
            editor.apply();
            
            Toast.makeText(this, "Pattern saved", Toast.LENGTH_SHORT).show();
            finish();
        } catch (JSONException e) {
            Toast.makeText(this, "Error saving pattern", Toast.LENGTH_SHORT).show();
        }
    }
}
