package com.lednotifier;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.lednotifier.ui.AppConfigActivity;
import com.lednotifier.ui.adapters.AppListAdapter;
import com.lednotifier.utils.DeviceUtils;

/**
 * Main entry point for the LED Notifier app.
 * This activity shows the list of configured apps and provides access to settings.
 */
public class MainActivity extends AppCompatActivity {

    private static final String ENABLED_NOTIFICATION_LISTENERS = "enabled_notification_listeners";
    private static final int REQUEST_NOTIFICATION_ACCESS = 100;
    
    private Button btnAddApp;
    private TextView tvNotificationAccess;
    private RecyclerView rvConfiguredApps;
    private AppListAdapter appListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // Check if we're running on a supported device
        if (!DeviceUtils.isSupported()) {
            Toast.makeText(this, "This app is designed for Unihertz Tank 2 Pro devices only", 
                    Toast.LENGTH_LONG).show();
            // We could finish() here, but for the conceptual design we'll continue
        }
        
        initViews();
        setupListeners();
        
        // Update notification access status
        updateNotificationAccessStatus();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        updateNotificationAccessStatus();
        // In a full implementation, we would refresh the app list here
    }
    
    private void initViews() {
        btnAddApp = findViewById(R.id.btn_add_app);
        tvNotificationAccess = findViewById(R.id.tv_notification_access);
        rvConfiguredApps = findViewById(R.id.rv_configured_apps);
        
        // Set up the RecyclerView
        rvConfiguredApps.setLayoutManager(new LinearLayoutManager(this));
        appListAdapter = new AppListAdapter(this);
        rvConfiguredApps.setAdapter(appListAdapter);
    }
    
    private void setupListeners() {
        btnAddApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isNotificationServiceEnabled()) {
                    requestNotificationAccess();
                } else {
                    startActivity(new Intent(MainActivity.this, AppConfigActivity.class));
                }
            }
        });
        
        tvNotificationAccess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestNotificationAccess();
            }
        });
    }
    
    private void updateNotificationAccessStatus() {
        if (isNotificationServiceEnabled()) {
            tvNotificationAccess.setText("Notification access granted");
            tvNotificationAccess.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_check, 0, 0, 0);
            btnAddApp.setEnabled(true);
        } else {
            tvNotificationAccess.setText("Notification access required - Tap to grant");
            tvNotificationAccess.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_warning, 0, 0, 0);
            btnAddApp.setEnabled(false);
        }
    }
    
    private boolean isNotificationServiceEnabled() {
        String packageName = getPackageName();
        String flat = Settings.Secure.getString(getContentResolver(),
                ENABLED_NOTIFICATION_LISTENERS);
        
        if (flat != null && !flat.isEmpty()) {
            String[] names = flat.split(":");
            for (String name : names) {
                if (packageName.equals(name)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private void requestNotificationAccess() {
        Intent intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
        startActivityForResult(intent, REQUEST_NOTIFICATION_ACCESS);
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == REQUEST_NOTIFICATION_ACCESS) {
            updateNotificationAccessStatus();
        }
    }
}
