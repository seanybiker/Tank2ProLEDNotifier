package com.lednotifier.models;

import android.os.Parcel;
import android.os.Parcelable;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Model class representing an LED notification pattern configuration.
 * Includes parameters for controlling the LED behavior for a specific app.
 */
public class NotificationPattern implements Parcelable {

    private String packageName;
    private String appName;
    private String color;
    private int duration;
    private int flashCount;
    private boolean enabled;
    private int priority;

    public NotificationPattern() {
        // Default values
        this.color = "#FF0000"; // Red
        this.duration = 3000;   // 3 seconds
        this.flashCount = 5;    // 5 flashes
        this.enabled = true;
        this.priority = 0;
    }

    // Parcelable implementation
    protected NotificationPattern(Parcel in) {
        packageName = in.readString();
        appName = in.readString();
        color = in.readString();
        duration = in.readInt();
        flashCount = in.readInt();
        enabled = in.readByte() != 0;
        priority = in.readInt();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(packageName);
        dest.writeString(appName);
        dest.writeString(color);
        dest.writeInt(duration);
        dest.writeInt(flashCount);
        dest.writeByte((byte) (enabled ? 1 : 0));
        dest.writeInt(priority);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<NotificationPattern> CREATOR = new Creator<NotificationPattern>() {
        @Override
        public NotificationPattern createFromParcel(Parcel in) {
            return new NotificationPattern(in);
        }

        @Override
        public NotificationPattern[] newArray(int size) {
            return new NotificationPattern[size];
        }
    };

    // Getters and setters
    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public int getFlashCount() {
        return flashCount;
    }

    public void setFlashCount(int flashCount) {
        this.flashCount = flashCount;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    /**
     * Convert this pattern to a JSON string for storage.
     */
    public String toJson() throws JSONException {
        JSONObject json = new JSONObject();
        json.put("packageName", packageName);
        json.put("appName", appName);
        json.put("color", color);
        json.put("duration", duration);
        json.put("flashCount", flashCount);
        json.put("enabled", enabled);
        json.put("priority", priority);
        return json.toString();
    }

    /**
     * Create a pattern from a JSON string.
     */
    public static NotificationPattern fromJson(String jsonString) throws JSONException {
        JSONObject json = new JSONObject(jsonString);
        NotificationPattern pattern = new NotificationPattern();
        pattern.setPackageName(json.getString("packageName"));
        pattern.setAppName(json.getString("appName"));
        pattern.setColor(json.getString("color"));
        pattern.setDuration(json.getInt("duration"));
        pattern.setFlashCount(json.getInt("flashCount"));
        pattern.setEnabled(json.getBoolean("enabled"));
        pattern.setPriority(json.getInt("priority"));
        return pattern;
    }
}
