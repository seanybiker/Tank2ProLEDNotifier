package com.lednotifier.ui;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.SearchView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.lednotifier.R;
import com.lednotifier.ui.adapters.AppListAdapter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Activity for selecting which apps to configure LED notifications for.
 */
public class AppConfigActivity extends AppCompatActivity {

    private RecyclerView rvApps;
    private ProgressBar progressBar;
    private SearchView searchView;
    private AppListAdapter adapter;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_config);
        
        // Set up the action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Select App");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        
        // Initialize views
        rvApps = findViewById(R.id.rv_apps);
        progressBar = findViewById(R.id.progress_bar);
        searchView = findViewById(R.id.search_view);
        
        // Set up RecyclerView
        rvApps.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AppListAdapter(this, true);
        rvApps.setAdapter(adapter);
        
        // Set up item click listener
        adapter.setOnItemClickListener(new AppListAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(ApplicationInfo appInfo) {
                Intent intent = new Intent(AppConfigActivity.this, PatternConfigActivity.class);
                intent.putExtra("package_name", appInfo.packageName);
                startActivity(intent);
            }
        });
        
        // Set up search functionality
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }
            
            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return true;
            }
        });
        
        // Load installed apps
        loadApps();
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    private void loadApps() {
        new LoadAppsTask().execute();
    }
    
    /**
     * Asynchronous task to load installed apps.
     */
    private class LoadAppsTask extends AsyncTask<Void, Void, List<ApplicationInfo>> {
        
        @Override
        protected void onPreExecute() {
            progressBar.setVisibility(View.VISIBLE);
            rvApps.setVisibility(View.GONE);
        }
        
        @Override
        protected List<ApplicationInfo> doInBackground(Void... voids) {
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
            List<ApplicationInfo> filteredApps = new ArrayList<>();
            
            // Filter for apps that can post notifications
            for (ApplicationInfo appInfo : installedApps) {
                if (pm.getLaunchIntentForPackage(appInfo.packageName) != null) {
                    filteredApps.add(appInfo);
                }
            }
            
            // Sort apps by name
            Collections.sort(filteredApps, new Comparator<ApplicationInfo>() {
                @Override
                public int compare(ApplicationInfo app1, ApplicationInfo app2) {
                    return app1.loadLabel(pm).toString().compareTo(
                            app2.loadLabel(pm).toString());
                }
            });
            
            return filteredApps;
        }
        
        @Override
        protected void onPostExecute(List<ApplicationInfo> appInfoList) {
            progressBar.setVisibility(View.GONE);
            rvApps.setVisibility(View.VISIBLE);
            
            adapter.setAppList(appInfoList);
            adapter.notifyDataSetChanged();
        }
    }
}
