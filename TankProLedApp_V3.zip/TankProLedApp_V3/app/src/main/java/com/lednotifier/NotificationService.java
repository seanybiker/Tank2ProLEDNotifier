package com.lednotifier;

import android.app.Notification;
import android.content.Context;
import android.content.SharedPreferences;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;
import android.util.Log;

import com.lednotifier.models.NotificationPattern;

/**
 * Service that listens for notifications and triggers LED patterns based on user configurations.
 * This service requires the BIND_NOTIFICATION_LISTENER_SERVICE permission to be granted by the user.
 */
public class NotificationService extends NotificationListenerService {

    private static final String TAG = "NotificationService";
    private static final String PREFS_NAME = "led_notifier_prefs";
    
    private LedController ledController;
    private SharedPreferences prefs;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "NotificationService created");
        
        ledController = new LedController(this);
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null) return;
        
        String packageName = sbn.getPackageName();
        Log.d(TAG, "Notification received from: " + packageName);
        
        // Ignore our own notifications to prevent feedback loops
        if (packageName.equals(getPackageName())) {
            return;
        }
        
        // Check if this app is configured for LED notifications
        if (isAppConfigured(packageName)) {
            processNotification(sbn);
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        // If needed, we could stop LED patterns when notifications are dismissed
        String packageName = sbn.getPackageName();
        
        // Check if this was the last notification from this app
        if (isAppConfigured(packageName) && !hasActiveNotificationsFrom(packageName)) {
            ledController.stopPattern(packageName);
        }
    }
    
    private boolean isAppConfigured(String packageName) {
        return prefs.contains("pattern_" + packageName);
    }
    
    private void processNotification(StatusBarNotification sbn) {
        String packageName = sbn.getPackageName();
        
        // Get notification details
        Notification notification = sbn.getNotification();
        String title = "";
        String text = "";
        
        if (notification.extras != null) {
            title = notification.extras.getString(Notification.EXTRA_TITLE, "");
            text = notification.extras.getString(Notification.EXTRA_TEXT, "");
        }
        
        // Get configured pattern for this app
        String patternJson = prefs.getString("pattern_" + packageName, "");
        if (TextUtils.isEmpty(patternJson)) {
            return;
        }
        
        try {
            // In a real implementation, we would parse the JSON to create the pattern
            // For this conceptual design, we'll create a placeholder pattern
            NotificationPattern pattern = new NotificationPattern();
            pattern.setPackageName(packageName);
            pattern.setColor("#FF0000"); // Red as default
            pattern.setDuration(3000);   // 3 seconds
            pattern.setFlashCount(5);    // Flash 5 times
            
            // Check notification priority/category for potential pattern adjustments
            int priority = notification.priority;
            if (priority >= Notification.PRIORITY_HIGH) {
                pattern.setFlashCount(10);  // More flashes for important notifications
            }
            
            // Execute the LED pattern
            ledController.executePattern(pattern);
            
        } catch (Exception e) {
            Log.e(TAG, "Error processing notification pattern", e);
        }
    }
    
    private boolean hasActiveNotificationsFrom(String packageName) {
        StatusBarNotification[] activeNotifications = getActiveNotifications();
        if (activeNotifications == null) return false;
        
        for (StatusBarNotification notification : activeNotifications) {
            if (notification.getPackageName().equals(packageName)) {
                return true;
            }
        }
        return false;
    }
}
