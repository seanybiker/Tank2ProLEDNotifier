package com.lednotifier.ui.adapters;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.lednotifier.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Adapter for displaying app lists in RecyclerViews.
 * Can be used both for showing configured apps and for selecting new apps to configure.
 */
public class AppListAdapter extends RecyclerView.Adapter<AppListAdapter.ViewHolder> implements Filterable {

    private Context context;
    private List<ApplicationInfo> appList;
    private List<ApplicationInfo> appListFull;
    private boolean selectMode;
    private OnItemClickListener listener;
    private static final String PREFS_NAME = "led_notifier_prefs";

    /**
     * Constructor for the adapter.
     * 
     * @param context The context
     * @param selectMode Whether this is being used for app selection (true) or displaying configured apps (false)
     */
    public AppListAdapter(Context context, boolean selectMode) {
        this.context = context;
        this.appList = new ArrayList<>();
        this.appListFull = new ArrayList<>();
        this.selectMode = selectMode;
    }

    /**
     * Constructor without select mode parameter - defaults to displaying configured apps.
     */
    public AppListAdapter(Context context) {
        this(context, false);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_app, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ApplicationInfo appInfo = appList.get(position);
        PackageManager pm = context.getPackageManager();

        // Set app name and icon
        holder.tvAppName.setText(appInfo.loadLabel(pm));
        holder.ivAppIcon.setImageDrawable(appInfo.loadIcon(pm));

        // If not in select mode, show additional info for configured apps
        if (!selectMode) {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String patternJson = prefs.getString("pattern_" + appInfo.packageName, "");
            
            if (!patternJson.isEmpty()) {
                holder.tvConfigured.setVisibility(View.VISIBLE);
            } else {
                holder.tvConfigured.setVisibility(View.GONE);
            }
        } else {
            holder.tvConfigured.setVisibility(View.GONE);
        }

        // Set click listener
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onItemClick(appInfo);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return appList.size();
    }

    /**
     * Set the app list to display.
     */
    public void setAppList(List<ApplicationInfo> appList) {
        this.appList = appList;
        this.appListFull = new ArrayList<>(appList);
        notifyDataSetChanged();
    }

    /**
     * Set the listener for app item clicks.
     */
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    /**
     * ViewHolder for app items.
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivAppIcon;
        TextView tvAppName;
        TextView tvConfigured;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivAppIcon = itemView.findViewById(R.id.iv_app_icon);
            tvAppName = itemView.findViewById(R.id.tv_app_name);
            tvConfigured = itemView.findViewById(R.id.tv_configured);
        }
    }

    /**
     * Interface for app item click events.
     */
    public interface OnItemClickListener {
        void onItemClick(ApplicationInfo appInfo);
    }

    @Override
    public Filter getFilter() {
        return appFilter;
    }

    private Filter appFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<ApplicationInfo> filteredList = new ArrayList<>();

            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(appListFull);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();
                PackageManager pm = context.getPackageManager();

                for (ApplicationInfo appInfo : appListFull) {
                    String appName = appInfo.loadLabel(pm).toString().toLowerCase();
                    if (appName.contains(filterPattern)) {
                        filteredList.add(appInfo);
                    }
                }
            }

            FilterResults results = new FilterResults();
            results.values = filteredList;
            results.count = filteredList.size();
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            appList.clear();
            appList.addAll((List) results.values);
            notifyDataSetChanged();
        }
    };
}
